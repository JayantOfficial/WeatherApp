//
//  MyWeatherModel.swift
//  Weather-App-Assignment
//
//  Created by Jayant on 18/06/21.
//

import Foundation

struct MyWeatherModel {
    let typeID: Int
    let city: String
    let temperature: Double
    
    var temperatureString: String {
        return String(format: "%.1f", temperature)
    }
    
    var type: String {
        switch typeID {
        case 801...804:
            return "cloud.bolt"
        case 800:
            return "sun.max"
        case 701...781:
            return "cloud.fog"
        case 600...622:
            return "cloud.snow"
        case 500...531:
            return "cloud.rain"
        case 300...321:
            return "cloud.drizzle"
        case 200...232:
            return "cloud.bolt"
        default:
            return "cloud"
        }
    }
}
