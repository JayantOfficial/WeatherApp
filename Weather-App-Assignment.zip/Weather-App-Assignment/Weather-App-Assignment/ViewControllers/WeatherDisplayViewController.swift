//
//  WeatherDisplayViewController.swift
//  Weather-App-Assignment
//
//  Created by Jayant on 18/06/21.
//

import UIKit
import CoreLocation
import CoreData

class WeatherDisplayViewController: UIViewController {
    
    @IBOutlet weak var conditionImageView: UIImageView!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var weatherModl : MyWeatherModel?
    let cityPickerView = UIPickerView()
    let toolBar = UIToolbar()
    var CityManagedObject : [NSManagedObject] = []
    let loadingViewController = LoadingViewController()
    var weatherManager = WeatherManager()
    let locationManager = CLLocationManager()
    var cityArray:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        locationManager.requestLocation()
        
        weatherManager.delegate = self
        cityPickerView.delegate = self
        fetchCityArrayFromDB()
    }
    
    //MARK:- Custom Methods
    private func search()
    {
        if let city = searchBar.text {
            add(loadingViewController)
            weatherManager.fetchWeather(city: city)
        }
        searchBar.endEditing(true)
    }
    
    @objc func onDoneButtonTapped()
    {
        self.search()
        toolBar.removeFromSuperview()
        cityPickerView.removeFromSuperview()
    }
    
    @objc func onCancelButtonTapped()
    {
        self.searchBar.text = ""
        toolBar.removeFromSuperview()
        cityPickerView.removeFromSuperview()
    }
    
    //MARK:- Custom Actions
    @IBAction func favouriteListClicked(_ sender: Any)
    {
        if cityArray.count == 0
        {
            self.showAlert(msg: "No city added in Favourite City List")
        }
        else
        {
            cityPickerView.delegate = self
            cityPickerView.dataSource = self
            cityPickerView.backgroundColor = UIColor.white
            cityPickerView.setValue(UIColor.black, forKey: "textColor")
            cityPickerView.autoresizingMask = .flexibleWidth
            cityPickerView.contentMode = .center
            cityPickerView.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
            self.view.addSubview(cityPickerView)
            
            toolBar.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50)
            toolBar.barStyle = .default
            toolBar.items = [
                UIBarButtonItem.init(title: "Cancel", style: .plain, target: self, action: #selector(onCancelButtonTapped)),
                UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil),
                UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(onDoneButtonTapped)),
            ]
            self.view.addSubview(toolBar)
        }
    }
    
    @IBAction func saveCurrentCity(_ sender: Any)
    {
        if self.cityArray.contains(weatherModl?.city ?? "")
        {
            showAlert(msg: "City is already added in your favourite List")
        }
        else
        {
            self.cityArray.append(weatherModl?.city ?? "")
            saveCityArrayToDB(cityArray: cityArray)
            showAlert(msg: "City added to your favourite List")
        }
    }
    
    @IBAction func currentLocationPressed(_ sender: Any) {
        locationManager.requestLocation()
    }
}

//MARK:- SearchBar Delegates
extension WeatherDisplayViewController: UISearchBarDelegate
{
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)
    {
        searchBar.showsCancelButton = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        self.searchBar.endEditing(true)
        self.searchBar.resignFirstResponder()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        if searchBar.text != ""
        {
            search()
            searchBar.showsCancelButton = false
            searchBar.endEditing(true)
            searchBar.resignFirstResponder()
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchBar.text = ""
        searchBar.showsCancelButton = false
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
    }
}

//MARK:- PickerView Delegates
extension WeatherDisplayViewController: UIPickerViewDelegate, UIPickerViewDataSource
{
    // MARK: UIPickerView Delegation
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        self.cityArray.count
    }
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return self.cityArray[row]
    }
    
    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        self.searchBar.text = self.cityArray[row]
    }
}


// MARK: - CLLocationManagerDelegate
extension WeatherDisplayViewController: CLLocationManagerDelegate
{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            locationManager.stopUpdatingLocation()
            let lat = location.coordinate.latitude
            let lon = location.coordinate.longitude
            add(loadingViewController)
            weatherManager.fetchWeather(latitude: lat, longitude: lon)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
        self.showAlert(msg: error.localizedDescription)
    }
}

// MARK: - WeatherManagerDelegate
extension WeatherDisplayViewController: WeatherManagerDelegate {
    
    func didUpdateWeather( _ weatherManager: WeatherManager, weather: MyWeatherModel) {
        DispatchQueue.main.async {
            
            self.weatherModl = weather
            self.temperatureLabel.text = weather.temperatureString
            self.cityLabel.text = weather.city
            self.conditionImageView.image = UIImage(systemName: weather.type)
            self.loadingViewController.remove()
        }
    }
    
    func didFailWithError(error: Error) {
        print(error)
        DispatchQueue.main.async {
            self.showAlert(msg: "Please Enter valid City Name")
            self.loadingViewController.remove()
        }
    }
}


// MARK: - CoreData Functions
extension WeatherDisplayViewController
{
    
    private func saveCityArrayToDB(cityArray: [String])
    {
        guard let data = try? JSONEncoder().encode(cityArray),
              let cityEncodedString = String(data: data, encoding: .utf8) else { return }
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "City", in: managedContext)!
        let favouriteCity = NSManagedObject(entity: entity, insertInto: managedContext)
        
        favouriteCity.setValue(cityEncodedString, forKeyPath: "cities")
        
        do {
            CityManagedObject.append(favouriteCity)
            try managedContext.save()
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    private func fetchCityArrayFromDB()
    {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "City")
        
        do {
            CityManagedObject = try managedContext.fetch(fetchRequest)
            
            for i in CityManagedObject {
                if let decodedAnswerString = i.value(forKey: "cities") as? String {
                    let data = Data(decodedAnswerString.utf8)
                    let citiesArray = try? JSONDecoder().decode([String].self, from: data)
                    
                    cityArray = citiesArray ?? []
                    print("City List: ", citiesArray ?? [""])
                }
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
}

